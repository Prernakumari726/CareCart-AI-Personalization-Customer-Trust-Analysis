import pandas as pd
import numpy as np
file_path = "C:\\Users\\Prerna Kumari\\OneDrive\\Desktop\\CareCart_Project\\CareCart_data.xlsx"

dim_customer = pd.read_excel(file_path, sheet_name="dim_customer")
fact_orders = pd.read_excel(file_path, sheet_name="fact_orders")
fact_engagement = pd.read_excel(file_path, sheet_name="fact_engagement")
fact_trust = pd.read_excel(file_path, sheet_name="fact_trust")

# Remove Duplicates
dim_customer = dim_customer.drop_duplicates(subset="cust_id")
fact_orders = fact_orders.drop_duplicates(subset="order_id")
fact_engagement = fact_engagement.drop_duplicates(subset="cust_id")
fact_trust = fact_trust.drop_duplicates(subset="cust_id")

# Remove invalid age and order values
dim_customer = dim_customer[dim_customer["age"] > 0]
fact_orders = fact_orders[fact_orders["order_value"] >= 0]

# Find Missing Data 
dim_customer[dim_customer.isna().any(axis=1)]
fact_orders[fact_orders.isna().any(axis=1)]
fact_engagement[fact_engagement.isna().any(axis=1)]
fact_trust[fact_trust.isna().any(axis=1)]

print(dim_customer.head())
print(fact_orders.head())
print(fact_engagement.head())
print(fact_trust.head())

# Find inconsistent text and typos
print(dim_customer["gender"].value_counts())
print(dim_customer["city"].value_counts())
print(dim_customer["acquisition_channel"].value_counts())
print(fact_orders["product_category"].value_counts())
print(fact_orders["order_type"].value_counts())
print(fact_orders["AI_assisted_order"].value_counts())
print(fact_engagement["chatbot_usage_flag"].value_counts())
print(fact_trust["unsubscribe_flag"].value_counts())
print(fact_trust["data_privacy_query_flag"].value_counts())
print(fact_trust["support_escalation_flag"].value_counts())

# Verify missing values
print(dim_customer.isna().sum())
print(fact_orders.isna().sum())
print(fact_engagement.isna().sum())
print(fact_trust.isna().sum())

# Check if data type correct or not 
dim_customer.info()
fact_orders.info()
fact_engagement.info()
fact_trust.info()

orders_agg = fact_orders.groupby("cust_id").agg(
    total_orders=("order_id", "count"),
    total_revenue=("order_value", "sum"),
    avg_order_value=("order_value", "mean"),
    ai_orders=("AI_assisted_order", lambda x: (x == 1).sum())
).reset_index()

master_data = dim_customer.merge(fact_engagement, on="cust_id", how="left") \
                           .merge(fact_trust, on="cust_id", how="left") \
                           .merge(orders_agg, on="cust_id", how="left")

output_path = r"C:\Users\Prerna Kumari\OneDrive\Desktop\CareCart_Project\CareCart_clean.xlsx"

with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
    dim_customer.to_excel(writer, sheet_name="dim_customer_clean", index=False)
    fact_orders.to_excel(writer, sheet_name="fact_orders_clean", index=False)
    fact_engagement.to_excel(writer, sheet_name="fact_engagement_clean", index=False)
    fact_trust.to_excel(writer, sheet_name="fact_trust_clean", index=False)
    master_data.to_excel(writer, sheet_name="master_data_clean", index=False)

# Data quality check shows no missing or inconsistent values.
# Hence, no further cleaning (imputation or standardization) was required.
